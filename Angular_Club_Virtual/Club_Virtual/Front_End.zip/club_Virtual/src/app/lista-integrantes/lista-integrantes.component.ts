import { Component } from '@angular/core';

@Component({
  selector: 'app-lista-integrantes',
  standalone: true,
  imports: [],
  templateUrl: './lista-integrantes.component.html',
  styleUrl: './lista-integrantes.component.css'
})
export class ListaIntegrantesComponent {

}
